var activeFlag = false;
var importCode;
var getInfo;
var clipboard;

/*jQuery extend func for get element path*/
jQuery.fn.extend({
    getPath: function() {
        var pathes = [];
        var parentId = '';
        this.each(function(index, element) {
            var path, $node = jQuery(element);
            while ($node.length && !parentId) {
                var realNode = $node.get(0),
                    name = realNode.localName;
                if (!name) { break; }
                name = name.toLowerCase();
                var parent = $node.parent();
                if (parent.attr('id')) {
                    parentId = '#' + parent.attr('id') + ' ';
                }
                if (parent.is('[id]')) {
                    var sel = '#' + parent.attr('id');
                    if ($(sel).length == 1 && $(sel).is(parent)) {
                        parentId = sel + ' ';
                    }
                } else {
                    if (parent.is('[data-getClass]')) {
                        var sel = parent.attr('data-getClass');
                        sel = '.' + sel.replace(/\s\s+/g, ' ').split(' ').join('.');
                        if ($(sel).length == 1 && $(sel).is(parent)) {
                            parentId = sel + ' ';
                        }
                    }
                }
                var sameTagSiblings = parent.children(name);
                if (sameTagSiblings.length > 1) {
                    allSiblings = parent.children();
                    var index = allSiblings.index(realNode) + 1;
                    if (index > 0) {
                        name += ':nth-child(' + index + ')';
                    }
                }
                path = name + (path ? ' > ' + path : '');
                $node = parent;
            }
            pathes.push(path);
        });

        //var path =$(parentId + pathes.join(',').replace('html > ',''));
        var result = $(parentId + pathes.join(',').replace('html > ', '')).text();
        return result;
    }
});

function cal(result) {

    var temp;
    var curl = 'https://backoffice.transferconnex.com/MobileDNDStatus/Index?MobileNo=' + result;
    // var curl = 'http://localhost:55874//MobileDNDStatus/Index?MobileNo=' + result;
    // $.ajax({
    // 	type: 'GET',
    // 	url: curl,
    // 	//async: false,
    // 	dataType: 'jsonp',
    // 	jsonp: "jsonp",
    // 	jsonpCallback: 'processMyData',
    // 	// success: function (data) {
    // 	// 	;
    // 	// 	console.log(data);

    // 	// 	// // for (var i = 0; i < data.length; i++) {
    // 	// 	// // 	if (result == data[i]) {
    // 	// 	// // 		temp = "<div><p class='col-3'>Y Client</p><p  class='col-3'>Y TPS</p><p class='col-3'>Y DND</p></div>";
    // 	// 	// // 		//	$(result).css('color','Green').append('<p><i class="fa fa-check"></i>Client</p>');
    // 	// 	// // 		return true;
    // 	// 	// // 	}
    // 	// 	// // 	else {
    // 	// 	// // 		temp = "<div><p class='col-3'>X Client</p><p class='col-3'>Y TPS</p><p class='col-3'>Y DND</p></div>";
    // 	// 	// // 	}

    // 	// 	// // }
    // 	// 	// var clientXY = data[0].isClient ? "<img src='" + chrome.extension.getURL("Check.png") + "'>" :
    // 	// 	// 	"<img src='" + chrome.extension.getURL("Cross.png") + "'>";
    // 	// 	// var dndXY = data[0].isDND ? "<img src='" + chrome.extension.getURL("Check.png") + "'>" :
    // 	// 	// 	"<img src='" + chrome.extension.getURL("Cross.png") + "'>";
    // 	// 	// var tpsXY = data[0].isTPS ? "<img src='" + chrome.extension.getURL("Check.png") + "'>" :
    // 	// 	// 	"<img src='" + chrome.extension.getURL("Cross.png") + "'>";

    // 	// 	// temp = "<div class='getrow'><div class='getcol'>" + clientXY + " Client</div><div class='getcol'>" + tpsXY + " TPS</div><div class='getcol'>" + dndXY + " DND</div></div>";
    // 	// 	// return true;
    // 	// },
    // 	error: function (err) {
    // 		console.log(err)
    // 	}
    // });
    $.ajax({
        url: curl,
        type: 'GET',
        async: false,
        dataType: 'json',
        success: function(data) {

                var clientXY = data.isClient ? "<img src='" + chrome.extension.getURL("Check.png") + "'>" :
                    "<img src='" + chrome.extension.getURL("Cross.png") + "'>";
                var dndXY = data.isDND ? "<img src='" + chrome.extension.getURL("Check.png") + "'>" :
                    "<img src='" + chrome.extension.getURL("Cross.png") + "'>";
                var tpsXY = data.isTPS ? "<img src='" + chrome.extension.getURL("Check.png") + "'>" :
                    "<img src='" + chrome.extension.getURL("Cross.png") + "'>";
                var prospectXY = data.isProspect ? "<img src='" + chrome.extension.getURL("Check.png") + "'>" :
                    "<img src='" + chrome.extension.getURL("Cross.png") + "'>";

                temp = "<div class='getrow'><div class='getcol'>" + clientXY + " Client</div><div class='getcol'>" + tpsXY + " TPS</div><div class='getcol'>" + dndXY + " DND</div><div class='getcol'>" + prospectXY + " Prospect</div><div class='getcol'><button id='btnCopy' onclick='CopyNumber()' value='" + result + "'>Copy</button></div></div>";

            }
            //dataType: 'jsonp',
            //jsonp: 'processMyData',
            //jsonpCallback: processMyData
    });
    return temp;

}

function CopyNumber() {
    var textToCopy = document.getElementById("btnCopy").value;
    navigator.clipboard.writeText(textToCopy);
}

/*Open Gen UI*/
var openGen = function() {

    if (window.jQuery) {
        $('body').attr('data-getPage', '');
        $('*[class]').each(function() {
            $(this).attr('data-getClass', $(this).attr('class'));
        });

        getInfo = $('.getInfo');
        var getShape = $('.getShape');
        var inserValFunc = function(val) {
            if (importCode !== undefined) {
                importCode.remove();
            }
            var result;
            var selectedtext = val;

            //x = val.replace(/()/g, "").replace("+", "").replace("-", "").replace(/\s/g, '').match(/(\d+)/);
            x = val.replace(/()/g, "").replace("+", "").replace("-", "").match("^(?=.*[0-9])[- +()0-9]+$");

            if (x != null && x.length > 0) {

                x = x[0];
            }
            // if ($.isNumeric(x) == true) {
            if (x != null) {

                if (x.length >= 6 && x.length <= 20) {
                    result = cal(x);
                    importCode = $('<div class="getWrap getMin"><div class="getClose"></div><div class="getHeader">' + result + '</div>')
                    importCode.appendTo('body');
                    document.getElementById("btnCopy").addEventListener("click", CopyNumber);
                    importCode.css({ top: event.clientY + 15, left: event.clientX - 150 });
                } else {
                    result = "phone number not valid";
                }
            } else {
                result = "phone number not valid";
            }


            // } 
            // else {
            //     result = "phone number not valid";
            // }

        }
        var checkSelFunc = function(el, sel) {
            if ($(sel).length == 1 && $(sel).is(el)) {
                inserValFunc(sel);
            } else {
                inserValFunc(el.getPath());
            }
        };
        var changeSelect = function(el) {
            var offset = el.offset();
            getShape.css({
                width: el.outerWidth(),
                height: el.outerHeight(),
                left: offset.left,
                top: offset.top
            })
        };
        var getPathFunc = function(e) {
            var el = $(e.target);
            if (!el.is('.getInput') && !el.is('.getWrap') && !el.is('.getHeader') && !el.is('.getAction') && !el.is('.getBtn') && !el.is('.getBtnIcon') && !el.is('.getShape') && !el.is('.getInfo') && !el.is('.getClose') && !el.is('.getSub') && !el.is('.getSubIcon') && !el.is('.getLogo')) {
                changeSelect(el);
                if (el.is('[id]')) {
                    var sel = '#' + el.attr('id');
                    checkSelFunc(el, sel);
                    return false;
                } else if (el.is('[data-getClass]')) {
                    var sel = el.attr('data-getClass');
                    sel = '.' + sel.replace(/\s\s+/g, ' ').split(' ').join('.');
                    checkSelFunc(el, sel);
                    return false;
                } else {
                    checkSelFunc(el, sel);
                    return false;
                }
                //inserValFunc(el.getPath());

            }
        };

        $(document).on('mouseover.getevent', '*', function(event) {

            var el = $(event.target);
            if (!el.is('.getWrap') && !el.is('.getWrap *')) {
                changeSelect(el);
            }
        });
        $(document).on('mouseenter.getevent', '*:not(.getWrap):not(.getWrap *)', function(event) {
            getPathFunc(event);
            event.preventDefault();
            return false;
        });
        $(document).on('mouseenter.getevent', '.getWrap', function() {
            changeSelect($('html'));
        });
        $(document).on('click', '.getClose', function() {
            activeFlag = false;
            closeGen();
        });
    } else {
        console.log('jQuery not connected!')
    }
};
var closeGen = function() {

    $(document).on('click', '.getClose');
    $(document).off('mouseenter.getevent', '.getWrap');
    $(document).off('mouseenter.getevent', '*:not(.getWrap):not(.getWrap *)');
    $(document).off('mouseover.getevent', '*');

    if (importCode !== undefined) {
        importCode.remove();
    }
    $('*[data-getClass]').removeAttr('data-getClass');
    $('body').removeAttr('data-getPage');
};

/*Get call from browser button*/
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {


    ////chrome.pageAction.setIcon({ tabId : sender.id , path: "../Cross.png" });
    if (msg.message == 'open_dialog_box') {


        if (msg.message == 'open_dialog_box') {

            if (activeFlag == false) {
                activeFlag = true;
                sendResponse(activeFlag);
                openGen();
            } else {
                activeFlag = false;
                sendResponse(activeFlag);
                closeGen();
            }
        }
    }


});

window.onload = function() {
    if (activeFlag == false) {
        activeFlag = true;
        openGen();
    } else {
        activeFlag = false;
        closeGen();
    }
    openGen();

};