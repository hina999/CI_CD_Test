chrome.browserAction.onClicked.addListener(function (tab) {

	chrome.tabs.query({ active: true }, function (tabs) {
		chrome.tabs.sendMessage(tab.id, {
			message: "open_dialog_box"
		}, function (isActive) {
			setIcon(tab.id, isActive);
		});

	});
});
function setIcon(tabId, isActive) {
	const path = isActive ? "get_started48.png" : "get_started_disabled48.png";
	chrome.browserAction.setIcon({
		path, tabId
	});
}